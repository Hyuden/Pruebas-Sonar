import * as dotenv from 'dotenv';
import { MiddlewareConsumer, Module } from '@nestjs/common';
import { TasaService } from './api/service';
import { TasaController } from './api/controller';
import { ConfigModule } from '@nestjs/config';
import { WinstonModule } from 'nest-winston';
import { LoggerConfig, PostgresConfig, HttpConfig } from './config';
import { LoggerMiddleware } from './api/middleware';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TasaRepository } from './api/repository/tasa.repository';
import { InMemoryDBModule } from '@nestjs-addons/in-memory-db';
import { HttpModule } from '@nestjs/axios';
import { dotEnvOptions, HealthController, ValidacionRutDvPer } from './api/utils';
import { TerminusModule } from '@nestjs/terminus';

dotenv.config({ path: dotEnvOptions.path });

const logger: LoggerConfig = new LoggerConfig();
const postgresOptions: PostgresConfig = new PostgresConfig();
const http: HttpConfig = new HttpConfig();

@Module({
  imports: [
    ConfigModule.forRoot(),
    WinstonModule.forRoot(logger.console()),
    TypeOrmModule.forRoot(postgresOptions.getOptions()),
    InMemoryDBModule.forRoot({}),
    HttpModule.register(http.getOptions()),
    TerminusModule,
    ValidacionRutDvPer

  ],
  controllers: [TasaController, HealthController],
  providers: [TasaService, TasaRepository],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(LoggerMiddleware)

  }
}
