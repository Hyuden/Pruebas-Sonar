import {
  Controller, Get, Param, Body, Post, Delete, Put, Inject, BadRequestException, Headers, HttpStatus, InternalServerErrorException, HttpException, UsePipes, ValidationPipe
} from '@nestjs/common';
import { TasaService } from '../service';
import { TasaDTO } from '../dto/tasa.dto';
import { ApiCreatedResponse, ApiParam, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Tasa } from '../entities';
import { Logger } from 'winston';
import { WINSTON_MODULE_PROVIDER } from 'nest-winston';
import { ErrorResponse, InvalidParametersErrorResponse, TasaResponseDTO } from '../responses';
import { ValidacionRutDvPer, dotEnvOptions } from '../utils';
import * as dotenv from 'dotenv';
import * as fs from 'fs';

@ApiTags('Tasa')
@Controller('tasas/v1')
export class TasaController {

  private env = dotenv.parse(fs.readFileSync(dotEnvOptions.path));

  constructor(
    private readonly tasaService: TasaService,
    @Inject(WINSTON_MODULE_PROVIDER)
    private readonly logger: Logger
  ) { }

  /**
 * Function get all users.
 * @author Esteban Martínez
 * @param null
 * @return {TasaResponseDTO} obj of tasa
 */

  @ApiOperation({ description: 'get Tasa anual y mensual' })
  @ApiCreatedResponse({
    description: 'get tasa credit',
    type: TasaResponseDTO,
  })
  @Get('consulta-tasas/:rutPer/:rutEmp/:sucemp/:codPro/:tipoAfil/:monto/:plazo/:moneda/:canal')
  @UsePipes()
  getTasa(
    @Headers() headers,
    @Param() params: TasaDTO
  ): Promise<TasaResponseDTO> {

    const dvPer2 = String(params.rutPer).substr(-1);
    const rutPerFinal = Number(params.rutPer.toString().slice(0, -1))

    if (headers && headers.id_transaccion && headers.id_transaccion.length > 0) {
      this.logger.info(`headers.id_transaccion: ${headers.id_transaccion}`);
    }
    else {
      this.logger.info('No header id_transaccion!!');

      var errorResponse = new ErrorResponse();
      errorResponse.title = 'Información de Cabecera';
      errorResponse.detail = 'Algunos de los parámetros en la cabecera no existe o es inválido';
      errorResponse.type = this.env["SWAGGER_URL"] || "";
      errorResponse.status = HttpStatus.BAD_REQUEST;
      errorResponse.codigoDeError = HttpStatus.BAD_REQUEST;

      var invalParamERTemp = new InvalidParametersErrorResponse();
      invalParamERTemp.name = 'id_transaccion';
      invalParamERTemp.reason = 'El parametro id_transaccion no existe o es inválido';
      var invalParamER: [InvalidParametersErrorResponse] = [invalParamERTemp];
      errorResponse['invalid-params'] = invalParamER;

      throw new BadRequestException(errorResponse);

    }


    if (!ValidacionRutDvPer.validacionRutPer(rutPerFinal, dvPer2)) {
      var errorResponse = new ErrorResponse();
      errorResponse.title = 'Ingreso de Parámetros';
      errorResponse.detail = 'Algunos de los parámetros ingresados es incorrecto o inválido';
      errorResponse.type = this.env["SWAGGER_URL"] || "";
      errorResponse.status = HttpStatus.BAD_REQUEST;
      errorResponse.codigoDeError = HttpStatus.BAD_REQUEST;

      var invalParamERTemp = new InvalidParametersErrorResponse();
      invalParamERTemp.name = 'rutPer';
      invalParamERTemp.reason = 'El parametro rutPer es inválido';
      var invalParamER: [InvalidParametersErrorResponse] = [invalParamERTemp];
      errorResponse['invalid-params'] = invalParamER;

      throw new BadRequestException(errorResponse);

    }


    const result = this.tasaService.tasaInteresByCredit(params)
      .then((resultF) => {

        console.log('notfound;:', resultF);
        this.logger.info(`response:${JSON.stringify(resultF)}`);
        return resultF;
      }).catch((errorResult) => {



        if (errorResult instanceof TasaResponseDTO) {


          var errorResponse = new ErrorResponse();
          errorResponse.title = 'Sin resultados';
          errorResponse.detail = 'No se encontro tasa asociada';
          errorResponse.type = this.env["SWAGGER_URL"] || "";
          errorResponse.status = HttpStatus.NO_CONTENT;
          errorResponse.codigoDeError = HttpStatus.NO_CONTENT;


          this.logger.info(`response:${JSON.stringify(errorResponse)}`);

          throw new HttpException(errorResponse, HttpStatus.NO_CONTENT,);


        }



        throw new InternalServerErrorException(errorResult, 'Internal Server Error');
      });

    return result;


  }

}
