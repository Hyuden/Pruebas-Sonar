import { Test, TestingModule } from '@nestjs/testing';
import { TasaController } from '.';
import { TasaService } from '../service';
import { WinstonModule } from 'nest-winston';
import { LoggerConfig, } from '../../config';
import { BadRequestException, HttpException, HttpStatus, NotFoundException } from '@nestjs/common';
import { TasaDTO } from 'src/api/dto';
import { ErrorResponse, TasaResponseDTO } from 'src/api/responses';

const logger: LoggerConfig = new LoggerConfig();

describe('TasaController', () => {
  let tasaController: TasaController;

  const countDataHeader = { id_trasaccion: "213jljlkjklq1" };

  const getResponse: TasaResponseDTO = {
    "tasaMensual": 1.0,
    "tasaAnual": 12.0,

  }


  const getResponseError: ErrorResponse = {
    "title": "Bad Request",
    "detail": "Bad Request Exception",
    "type": "http://localhost:8081/api",
    "status": 400,
    "codigoDeError": 400,
    "invalid-params": [
      {
        "name": "rutPer",
        "reason": "El parametro rutPer debe ser un valor numérico entero"
      }
    ]



  };



  const getResponseErrorNullParameter: ErrorResponse = {
    "title": "Ingreso de Parámetros",
    "detail": "Algunos de los parámetros ingresados es incorrecto o inválido",
    "type": "http://localhost:8081/api",
    "status": 400,
    "codigoDeError": 400,
    "invalid-params": [
      {
        "name": "rutPer",
        "reason": "El parametro rutPer es inválido"
      }
    ]

  };


  const paramsMock = {
    "rutPer": 1,
    "rutEmp": 4177206,
    "sucemp": "002",
    "codPro": "DIG",
    "tipoAfil": "PBSC",
    "monto": 1000000,
    "plazo": 18,
    "moneda": "CLP",
    "canal": "WEB",
  } as TasaDTO;

  const paramsMockInvalid = {
    "rutPer": 4177206,
    "rutEmp": 4177206,
    "sucemp": "002",
    "codPro": "DIG",
    "tipoAfil": "PBSC",
    "monto": 1000000,
    "plazo": 18,
    "moneda": "CLP",
    "canal": "WEB",
  } as TasaDTO;


  const tasaInteresByCredit = {
    tasaInteresByCredit: jest.fn().mockImplementation(() =>
      Promise.resolve(getResponse)),

    tasaInteresByCreditError: jest.fn().mockImplementation(() =>
      Promise.resolve(getResponseError)),

    tasaInteresByCreditNullParameters: jest.fn().mockImplementation(() =>
      Promise.resolve(getResponseError)),



  }

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      imports: [WinstonModule.forRoot(logger.console())],
      controllers: [TasaController],
      providers: [TasaService],
    })
      .overrideProvider(TasaService)
      .useValue(tasaInteresByCredit)
      .compile();

    tasaController = app.get<TasaController>(TasaController);
  });

  it('should be defined', () => {
    expect(tasaController).toBeDefined();
  });

  describe('tasaInteresByCredit', () => {


    it('should throw tasaInteresByCredit NOT_FOUND', async () => {

      const mockError = new HttpException('No Content', HttpStatus.NO_CONTENT);
      jest.spyOn(tasaController, 'getTasa').mockRejectedValue(new HttpException('No Content', HttpStatus.NO_CONTENT));
      await expect(tasaController.getTasa(countDataHeader, paramsMock)).rejects.toThrow(mockError);
      await expect(tasaController.getTasa(countDataHeader, paramsMock)).rejects.toThrow(new HttpException('No Content', HttpStatus.NO_CONTENT));
    });

  });



  describe('tasaInteresByCreditError', () => {

    it('should get tasaInteresByCreditError', async () => {

      jest.spyOn(tasaController, 'getTasa').mockRejectedValue(new BadRequestException({
        "$schema": "http://json-schema.org/draft-04/schema#",
        "description": "Esquema JSON de respuesta para casos de Error o Falla.",
        "type": "object",
        "properties": getResponseError
      })
      );
      await expect(tasaController.getTasa(countDataHeader, paramsMockInvalid)).rejects.toThrow(new BadRequestException({
        "$schema": "http://json-schema.org/draft-04/schema#",
        "description": "Esquema JSON de respuesta para casos de Error o Falla.",
        "type": "object",
        "properties": getResponseError
      })
      );

    });

  });

  describe('tasaInteresByCreditNullParameters', () => {

    it('should get tasaInteresByCreditNullParameters', async () => {

      jest.spyOn(tasaController, 'getTasa').mockRejectedValue(new BadRequestException({
        "$schema": "http://json-schema.org/draft-04/schema#",
        "description": "Esquema JSON de respuesta para casos de Error o Falla.",
        "type": "object",
        "properties": getResponseErrorNullParameter
      })
      );
      await expect(tasaController.getTasa(countDataHeader, null)).rejects.toThrow(new BadRequestException({
        "$schema": "http://json-schema.org/draft-04/schema#",
        "description": "Esquema JSON de respuesta para casos de Error o Falla.",
        "type": "object",
        "properties": getResponseErrorNullParameter
      })
      );

    });
  });





});





