
export class ValidacionRutDvPer {


    /**
     * Function get digito varificador.
     * @author Emmanuel Carballo
     * @param T
     * @return {any} digito verificador
     */
    private static validacionDvPer(T): any {

        var M = 0, S = 1;
        for (; T; T = Math.floor(T / 10))
            S = (S + T % 10 * (9 - M++ % 6)) % 11;
        return S ? S - 1 : 'k';
    }

    /**
     * Function get rutPer valid or not
     * @author Emmanuel Carballo
     * @param rutPer
     * @param dvPer
     * @return {booelan} validacion RutPer
     */
    public static validacionRutPer(rutPer: number, dvPer: string): boolean {

        if (!/^[0-9]+[-|‐]{1}[0-9kK]{1}$/.test(rutPer + '-' + dvPer)) {
            return false;
        }
        var digv = dvPer;
        var rut = rutPer;
        if (digv == 'K') digv = 'k';
        return (this.validacionDvPer(rut) == digv);
    }

    /**
     * Function get rutPer valid or not
     * @author Emmanuel Carballo
     * @param dvPer
     * @return {booelan} validacion DvPer
     */
    public static validacionVariasDvPer(dvPer: string): boolean {
        if (dvPer.length > 1) return false;
        else return true;
    }
}
