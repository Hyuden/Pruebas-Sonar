import { IsNotEmpty, IsInt, IsString, IsArray } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class InvalidParametersErrorResponse {

    @IsString()
    @IsNotEmpty()
    @ApiProperty()
    name: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty()
    reason: string;
}


export class ExternalServiceErrorResponse {

    @IsString()
    @IsNotEmpty()
    @ApiProperty()
    message: string;

    @IsInt()
    @IsNotEmpty()
    @ApiProperty()
    status: number;

    @IsString()
    @IsNotEmpty()
    @ApiProperty()
    name: string;

    @ApiProperty()
    stack?: any;
}

export class ErrorResponse {

    @IsInt()
    @IsNotEmpty()
    @ApiProperty()
    codigoDeError: number;

    @IsString()
    @IsNotEmpty()
    @ApiProperty()
    title: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty()
    detail: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty()
    type: string;

    @IsInt()
    @IsNotEmpty()
    @ApiProperty()
    status: number;

    @IsString()
    @ApiProperty()
    instance?: string;

    @IsArray()
    @ApiProperty()
    'invalid-params'?: [InvalidParametersErrorResponse];

    @ApiProperty()
    'external-service-error'?: ExternalServiceErrorResponse;

}
