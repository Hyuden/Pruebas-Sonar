import { MaxLength, IsNotEmpty, IsString, IsNumber, IsNumberString, MinLength, IsInt } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class TasaDTO {

    @IsNumberString({}, { message: '{"name":"rutPer", "reason":"El parametro rutPer debe ser un valor numérico entero"}' })
    @IsNotEmpty({ message: '{"name":"rutPer", "reason":"El parametro rutPer no debe estar vacio"}' })
    @ApiProperty()
    rutPer: number;

    @IsNumberString({}, { message: '{"name":"rutEmp", "reason":"El parametro rutEmp debe ser un valor numérico entero"}' })
    @IsNotEmpty({ message: '{"name":"rutEmp", "reason":"El parametro rutEmp no debe estar vacio"}' })
    @ApiProperty()
    rutEmp: number;


    @IsString()
    @MaxLength(3, { message: '{"name":"sucemp", "reason":"El parametro sucemp no puede tener mas de 8 dígitos"}' })
    @MinLength(1, { message: '{"name":"sucemp", "reason":"El parametro sucemp no puede tener menos de 1 dígito"}' })
    @IsNotEmpty({ message: '{"name":"sucemp", "reason":"El parametro sucemp no debe estar vacio"}' })
    @ApiProperty()
    sucemp: string;

    @IsString()
    @MaxLength(7, { message: '{"name":"codPro", "reason":"El parametro codPro no puede tener mas de 8 dígitos"}' })
    @MinLength(1, { message: '{"name":"codPro", "reason":"El parametro codPro no puede tener menos de 1 dígito"}' })
    @IsNotEmpty({ message: '{"name":"codPro", "reason":"El parametro codPro no debe estar vacio"}' })
    @ApiProperty()
    codPro: string;


    @IsString()
    @MaxLength(7, { message: '{"name":"tipoAfil", "reason":"El parametro tipoAfil no puede tener mas de 8 dígitos"}' })
    @MinLength(1, { message: '{"name":"tipoAfil", "reason":"El parametro tipoAfil no puede tener menos de 1 dígito"}' })
    @IsNotEmpty({ message: '{"name":"tipoAfil", "reason":"El parametro tipoAfil no debe estar vacio"}' })
    @ApiProperty()
    tipoAfil: string;


    @IsNumberString({}, { message: '{"name":"monto", "reason":"El parametro monto debe ser un valor numérico"}' })
    @IsNotEmpty({ message: '{"name":"monto", "reason":"El parametro monto no debe estar vacio"}' })
    @ApiProperty()
    monto: number;


    @IsNumberString({}, { message: '{"name":"plazo", "reason":"El parametro plazo debe ser un valor numérico entero"}' })
    @IsNotEmpty({ message: '{"name":"plazo", "reason":"El parametro plazo no debe estar vacio"}' })
    @ApiProperty()
    plazo: number;

    @IsString()
    @MaxLength(7, { message: '{"name":"moneda", "reason":"El parametro moneda no puede tener mas de 8 dígitos"}' })
    @MinLength(1, { message: '{"name":"moneda", "reason":"El parametro moneda no puede tener menos de 1 dígito"}' })
    @IsNotEmpty({ message: '{"name":"moneda", "reason":"El parametro moneda no debe estar vacio"}' })
    @ApiProperty()
    moneda: string;

    @IsString()
    @MaxLength(10, { message: '{"name":"canal", "reason":"El parametro canal no puede tener mas de 8 dígitos"}' })
    @MinLength(1, { message: '{"name":"canal", "reason":"El parametro canal no puede tener menos de 1 dígito"}' })
    @IsNotEmpty({ message: '{"name":"canal", "reason":"El parametro canal no debe estar vacio"}' })
    @ApiProperty()
    canal: string;

}





