export * from './tasa.entity';
