import { PrimaryGeneratedColumn, Column, Entity } from 'typeorm';
import { ApiProperty } from '@nestjs/swagger';
import { MaxLength, IsNotEmpty, IsString, IsNumber } from 'class-validator';

@Entity('tasas')
export class Tasa {

    @ApiProperty()
    @PrimaryGeneratedColumn()
    id: number;

    @IsNumber()
    @IsNotEmpty()
    @ApiProperty()
    @Column({ nullable: true })
    tasaAnual: number;

    @IsNumber()
    @IsNotEmpty()
    @ApiProperty()
    @Column({ nullable: true })
    tasaMensual: number;
}