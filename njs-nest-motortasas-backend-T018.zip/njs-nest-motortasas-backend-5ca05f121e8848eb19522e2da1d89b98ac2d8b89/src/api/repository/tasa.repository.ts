

import { Console } from 'console';
import { EntityRepository, getManager, Repository } from 'typeorm';
import { TasaDTO } from '../dto';
import { Tasa } from '../entities';
import { TasaResponseDTO } from '../responses';

@EntityRepository(TasaDTO)
export class TasaRepository extends Repository<TasaDTO> {

    public async tasaInteresByCredit(body: TasaDTO): Promise<TasaResponseDTO> {
        const promiseTasaResp: Promise<TasaResponseDTO> = new Promise<TasaResponseDTO>(async (resolve, reject) => {


            const query = `
            SELECT "DT"."DET_TASAANUAL", "DT"."DET_TASAMENSUAL"
            FROM "EXMTASA"."TAS_DETALLETASA" AS "DT"
            JOIN "EXMTASA"."TAS_RESTRICMET" AS "TR" 
            ON "TR"."RES_IDTASA" = "DT"."DET_IDTASA"
            WHERE "DT"."DET_PLAZODESDE" =  ${body.plazo} 
            OR "DT"."DET_PLAZOHASTA" =  ${body.plazo} 
            AND "DT"."DET_MONTODESDE" =  ${body.monto} 
            OR "DT"."DET_MONTOHASTA" =  ${body.monto} 
            AND "TR"."RES_TIPOAFILI" =  '${body.tipoAfil}'
            AND "TR"."RES_CANAL" =  '${body.canal}' 
            AND "TR"."RES_PRODUCTO" =  '${body.codPro}'`;

            console.log(query)

            try {
                const queryProcess = await getManager().query(query
                );

                const tasaResp = new TasaResponseDTO();
                tasaResp.tasaAnual = queryProcess[0] ? queryProcess[0].DET_TASAANUAL : 0;
                tasaResp.tasaMensual = queryProcess[0] ? queryProcess[0].DET_TASAMENSUAL : 0;

                console.log(queryProcess)
                console.log('0000')
                if (!queryProcess[0]) {

                    console.log('bbb')
                    reject(tasaResp)
                }

                resolve(tasaResp);
            }
            catch (errorQ) {
                console.log('111'), reject(errorQ)
            }

        });


        return await promiseTasaResp;
    }

}
