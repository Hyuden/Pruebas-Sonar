import { Injectable, NotFoundException } from '@nestjs/common';
import { TasaRepository } from '../repository';
import { InjectRepository } from '@nestjs/typeorm';
import { TasaDTO } from '../dto';
import { TasaResponseDTO } from '../responses';



@Injectable()
export class TasaService {

  constructor(
    @InjectRepository(TasaRepository)
    private tasaRepository: TasaRepository,


  ) {
  }


  async tasaInteresByCredit(body: TasaDTO): Promise<TasaResponseDTO> {

    return await this.tasaRepository.tasaInteresByCredit(body);

  }





}