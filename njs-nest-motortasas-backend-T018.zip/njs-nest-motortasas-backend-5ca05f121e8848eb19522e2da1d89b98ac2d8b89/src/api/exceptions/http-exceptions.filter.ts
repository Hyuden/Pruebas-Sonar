import * as dotenv from 'dotenv';
import * as fs from 'fs';
import { ExceptionFilter, Catch, ArgumentsHost, HttpException } from '@nestjs/common';
import { Response, Request } from 'express';
import { ErrorResponse, InvalidParametersErrorResponse } from '../responses';
import { dotEnvOptions } from '../utils/dotenv-options';

@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
    catch(exception: HttpException, host: ArgumentsHost) {

        const env = dotenv.parse(fs.readFileSync(dotEnvOptions.path));
        const ctx = host.switchToHttp();
        const response = ctx.getResponse<Response>();
        const request = ctx.getRequest<Request>();
        const status = (exception.getStatus) ? exception.getStatus() : 500;

        var objError;

        if (exception.getResponse() instanceof ErrorResponse) {
            objError = exception.getResponse();
        } else {
            objError = new ErrorResponse();

            if (exception.getResponse()["error"] != undefined || exception.getResponse()["error"] != null) {
                objError.title = exception.getResponse()["error"];
                objError.detail = exception.message;
            } else {
                objError.title = exception.name;
                objError.detail = exception.message;
            }

            objError.type = env["SWAGGER_URL"] || "";
            objError.status = status;

            objError.codigoDeError = status;
            let invalidParamsList = Array<InvalidParametersErrorResponse>();



            if (Array.isArray(exception.getResponse()["message"]) && exception.getResponse()["message"].length > 0) {
                exception.getResponse()["message"].forEach(key => {

                    console.log('exception', exception.getResponse()["message"])

                    var objStr = JSON.parse(key);
                    var invalidParams: InvalidParametersErrorResponse = {
                        name: objStr.name,
                        reason: objStr.reason
                    }

                    invalidParamsList.push(invalidParams);

                });

                objError["invalid-params"] = invalidParamsList;

            }

        }

        response
            .status(status)
            .json({
                "$schema": "http://json-schema.org/draft-04/schema#",
                "description": "Esquema JSON de respuesta para casos de Error o Falla.",
                "type": "object",
                properties: objError
            });
    }
}
